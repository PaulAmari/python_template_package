# Example package

This is a simple example package for learning purpose.
./docs/                 documentation
./scripts/              top-level scripts
./src/mypackage/        the main package with the source code
./src/mypackage/test    unit tests