def add_integers(a: int, b: int):
    """Sum two integers

    Args:
        a (int): 
        b (int): 

    Returns:
        int: sum of the integer inputs a and b
    """
    return a + b
